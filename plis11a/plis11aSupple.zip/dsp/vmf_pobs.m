function vmf = vmf_pobs(pobs, kappa, Q)
% vmf = vmf_pobs(pobs, kappa, Q) - returns partial observation vMF
%                                  structure
%
% INPUT:
%        pobs  - 2x(#obs) matrix with (x,y) coordinates of observed
%                assignments in the permutations matrix
%        kappa - noise concentration parameter in the observation
%                vMF distribution
%        Q     - rotation matrix
% OUTPUT:
% vmf              -  parameters of the result as a structure with
%                     fields 'mu' and 'kappa'
%                     vmf.mu    - mean
%                     vmf.kappa - concentration
%
% Copyright (c) 2010, Sergey Plis
% last edited: <2010-10-20 00:25:24 pliz>
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free  Software Foundation; either  version 2 of the  License, or
% (at your option) any later version.
%
% This program is distributed in the  hope that it will be useful, but
% WITHOUT  ANY   WARRANTY;  without  even  the   implied  warranty  of
% MERCHANTABILITY or  FITNESS FOR A  PARTICULAR PURPOSE.  See  the GNU
% General Public License for more details.

n     = sqrt(size(Q, 1));
idx   = sub2ind([n,n], pobs(1,:), pobs(2,:));
sig   = sum(Q(idx, :), 1)' * (1 - 1/n);
mu    = sig/norm(sig,2);
kappa = norm(kappa * sig,2)/sqrt(n-1);
vmf   = struct('mu', mu, 'kappa', kappa);

% Local Variables:
% mode: MATLAB
% write-file-hooks:   (time-stamp)
% time-stamp-active:  t
% time-stamp-start:   "last edited: <"
% time-stamp-end:     ">"
% time-stamp-line-limit: 20
% End:
