function O = updateOmega(O, obs, acc)
% updateOmega(O, obs, acc) - update information matrix based on
%                            observations
% INPUT:
%         O - initial [n x n] information matrix
%       obs - [2 x k] observation pairs of tracks and objects for k
%             observations 
%       acc - either a scalar or a k-element vector of the
%             probability of observing object obs(1,i) at track
%             obs(2,i)
%
% OUTPUT:
%         O - updated information matrix
%
% REFERENCES:
%     equation (10) of [*]
% [*] Schumitsch,  B., Thrun, S.,  Bradski, G., and Olukotun,  K.: The
%     Information-Form  Data  Association   Filter  ,  Proceedings  of
%     Conference on Neural  Information Processing Systems (NIPS), MIT
%     Press, 2005
% last edited: <2010-10-27 10:23:17 pliz>
n = size(O,2);
idx = sub2ind([n,n],obs(1,:),obs(2,:));
O(idx) = O(idx) + log(acc*(n-1)/(1-acc));
% Copyright (C) 2010, Sergey Plis  [s.m.plis@gmail.com]
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free  Software Foundation; either  version 2 of the  License, or
% (at your option) any later version.
%
% This program is distributed in the  hope that it will be useful, but
% WITHOUT  ANY   WARRANTY;  without  even  the   implied  warranty  of
% MERCHANTABILITY or  FITNESS FOR A  PARTICULAR PURPOSE.  See  the GNU
% General Public License for more details.
% Local Variables:
% mode: MATLAB
% write-file-hooks:   (time-stamp)
% time-stamp-active:  t
% time-stamp-start:   "last edited: <"
% time-stamp-end:     ">"
% time-stamp-line-limit: 20
% End:
