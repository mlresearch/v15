function [E,P] = predictErr(O, tru),
% Requires:
%           la perm2matrix
P = la(-O,1);
E = amat(P-perm2matrix(tru))/2/n;

function s = amat(M), s = sum(abs(M(:)));
