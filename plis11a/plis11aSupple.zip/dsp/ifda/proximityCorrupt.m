function p = proximityCorrupt(p, Mflip)
% proximityCorrupt(p, Mflip) - corrupt permutation p according to
%                              probability model in Mflip
% INPUT:
%         p - n-element permutation vector
%     Mflip - [n x n] symmetric matrix of pairwise swap
%             probabilities
%
% OUTPUT:
%         p - corrupted version of the permutation vector
%
% last edited: <2010-10-27 10:15:48 pliz>

n = size(Mflip,1); Mflip([1:n+1:n^2]) = 0;
idx = find(triu(Mflip > rand(size(Mflip))) == 1);
for k=1:length(idx),
    [i,j] = ind2sub([n,n],idx(k));
    p([i,j]) = p([j,i]);
end

% Copyright (C) 2010, Sergey Plis  [s.m.plis@gmail.com]
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free  Software Foundation; either  version 2 of the  License, or
% (at your option) any later version.
%
% This program is distributed in the  hope that it will be useful, but
% WITHOUT  ANY   WARRANTY;  without  even  the   implied  warranty  of
% MERCHANTABILITY or  FITNESS FOR A  PARTICULAR PURPOSE.  See  the GNU
% General Public License for more details.
% Local Variables:
% mode: MATLAB
% write-file-hooks:   (time-stamp)
% time-stamp-active:  t
% time-stamp-start:   "last edited: <"
% time-stamp-end:     ">"
% time-stamp-line-limit: 20
% End:
