function O = initOmega(n), 
% initOmega(n) - returns [n x n] random permutation matrix
%
% REQUIRES: 
%         perm2matrix
O = perm2matrix(randperm(n))+eps;
