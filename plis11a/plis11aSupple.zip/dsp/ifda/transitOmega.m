function O = transitOmega(O, Mflip)
% transitOmega(O, Mflip) - update information matrix based on
%                          transition model provided in Mflip
% INPUT:
%         O - initial [n x n] information matrix
%     Mflip - [n x n] symmetric matrix of pairwise swap
%             probabilities
%
% OUTPUT:
%         O - updated information matrix
% REFERENCES:
%     equation (11) of [*]
% [*] Schumitsch,  B., Thrun, S.,  Bradski, G., and Olukotun,  K.: The
%     Information-Form  Data  Association   Filter  ,  Proceedings  of
%     Conference on Neural  Information Processing Systems (NIPS), MIT
%     Press, 2005

% last edited: <2010-10-26 15:38:55 pliz>
    M = filldiag(Mflip)*exp(O);
    O = log(M/max(M(:))+eps);
    
function M = filldiag(M)
    n = size(M,1); M([1:n+1:n^2]) = 0;
    M([1:n+1:n^2]) = 1 - sum(M);
    
% Copyright (C) 2010, Sergey Plis  [s.m.plis@gmail.com]
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free  Software Foundation; either  version 2 of the  License, or
% (at your option) any later version.
%
% This program is distributed in the  hope that it will be useful, but
% WITHOUT  ANY   WARRANTY;  without  even  the   implied  warranty  of
% MERCHANTABILITY or  FITNESS FOR A  PARTICULAR PURPOSE.  See  the GNU
% General Public License for more details.
% Local Variables:
% mode: MATLAB
% write-file-hooks:   (time-stamp)
% time-stamp-active:  t
% time-stamp-start:   "last edited: <"
% time-stamp-end:     ">"
% time-stamp-line-limit: 20
% End:    
