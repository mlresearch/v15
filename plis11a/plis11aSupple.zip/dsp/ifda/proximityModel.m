function M = proximityModel(coords, scale, strength)
% proximityModel(coords, scale, strength)
%               for given object locations compute their flip
%               probability matrix
% INPUT:
%        coords - [n x d] d-dimensional locations of n objects
%         scale - how far objects should be for a significant
%                 decrease in the flip probability
%      strength - strength of the flip probability
% OUTPUT:
%             M - symmetric matrix of flip probabilities
%
% last edited: <2010-10-26 16:03:14 pliz>
if ~exist('scale'),    scale    = 0.1; end
if ~exist('strength'), strength = 0.1; end
M = squareform(strength*exp(-(pdist(coords).^2)./(2*scale^2)));
% Copyright (C) 2010, Sergey Plis  [s.m.plis@gmail.com]
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free  Software Foundation; either  version 2 of the  License, or
% (at your option) any later version.
%
% This program is distributed in the  hope that it will be useful, but
% WITHOUT  ANY   WARRANTY;  without  even  the   implied  warranty  of
% MERCHANTABILITY or  FITNESS FOR A  PARTICULAR PURPOSE.  See  the GNU
% General Public License for more details.
% Local Variables:
% mode: MATLAB
% write-file-hooks:   (time-stamp)
% time-stamp-active:  t
% time-stamp-start:   "last edited: <"
% time-stamp-end:     ">"
% time-stamp-line-limit: 20
% End:
