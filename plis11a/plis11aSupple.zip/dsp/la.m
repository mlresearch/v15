function P = la(M, kind)
% la(M, kind) -  takes as an input a weight matrix  and then finds the
%                nearest permutation
%                         
% INPUT: M - a weight matrix
%     kind - a switch between exact and slow bipartite matching
%            solver (0) and an approximate but a very fast solver (1)
% OUTPUT:
%        P - permutation matrix nearest in Euclidean sence to M
%            
% REQUIRES:
%      munkres jvlap
% last edited: <2010-10-24 11:51:38 pliz>
n      = length(M);
P      = zeros(n,n);
switch kind
  case 0
    P(munkres(M) + [0:n-1]*n) = 1;
  case 1
    P(jvlap(M)'  + [0:n-1]*n) = 1;
end
% Copyright (C) 2010, Sergey Plis  [s.m.plis@gmail.com]
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free  Software Foundation; either  version 2 of the  License, or
% (at your option) any later version.
%
% This program is distributed in the  hope that it will be useful, but
% WITHOUT  ANY   WARRANTY;  without  even  the   implied  warranty  of
% MERCHANTABILITY or  FITNESS FOR A  PARTICULAR PURPOSE.  See  the GNU
% General Public License for more details.
% Local Variables:
% mode: MATLAB
% write-file-hooks:   (time-stamp)
% time-stamp-active:  t
% time-stamp-start:   "last edited: <"
% time-stamp-end:     ">"
% time-stamp-line-limit: 20
% End:
