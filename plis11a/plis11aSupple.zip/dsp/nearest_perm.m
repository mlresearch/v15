function P = nearest_perm(x, iQ, kind)
% nearest_perm(x,iQ,kind) - takes  as  an input  a  point  in  S^d,
%                           transforms  it back  to the  original space
%                           using Q and iQ,  and then finds the nearest
%                           permutation
% INPUT: x - a point on a unit hypersphere (S^d)
%       iQ - inverse of the orthogonal basis for the
%            n^2-dimensional space
%     kind - a switch between exact and slow bipartite matching
%            solver (0) and an approximate but a very fast solver (1)
% OUTPUT:
%        P - permutation matrix nearest in Euclidean sence to
%            n^2-dimesional representation of x
% REQUIRES:
%      hs2u munkres jvlap
% last edited: <2010-10-24 11:51:04 pliz>

n      = sqrt(length(x)) + 1;
KM     = reshape((hs2u(x, iQ) - 1).^2, n, n);
P      = la(KM, kind);

% Copyright (C) 2010, Sergey Plis  [s.m.plis@gmail.com]
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free  Software Foundation; either  version 2 of the  License, or
% (at your option) any later version.
%
% This program is distributed in the  hope that it will be useful, but
% WITHOUT  ANY   WARRANTY;  without  even  the   implied  warranty  of
% MERCHANTABILITY or  FITNESS FOR A  PARTICULAR PURPOSE.  See  the GNU
% General Public License for more details.
%
% Local Variables:
% mode: MATLAB
% write-file-hooks:   (time-stamp)
% time-stamp-active:  t
% time-stamp-start:   "last edited: <"
% time-stamp-end:     ">"
% time-stamp-line-limit: 20
% End:
