function r = hs2u(x,iQ)
% r = hs2u(x,iQ) - transform a  point on a  unit hypersphere  to the
%                  corresponding   point  on  the   Birkhoff  polytope
%                  inscribing hypersphere in n^2-dimensional space
% INPUT:  x  - (n-1)^2-element unit length vector
% OUTPUT: iQ - [nxn] orthogonal matrix
%
% Copyright (C) 2010, Sergey Plis  [s.m.plis@gmail.com]
% last edited: <2010-10-20 01:16:22 pliz>
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free  Software Foundation; either  version 2 of the  License, or
% (at your option) any later version.
%
% This program is distributed in the  hope that it will be useful, but
% WITHOUT  ANY   WARRANTY;  without  even  the   implied  warranty  of
% MERCHANTABILITY or  FITNESS FOR A  PARTICULAR PURPOSE.  See  the GNU
% General Public License for more details.

r = iQ * [x; [1:length(iQ)-length(x)]'*0.0];     % to complete space
n = sqrt(length(r));
r = r*sqrt(n-1) + 1/n; % rescale and shift center of mass

% Local Variables:
% mode: MATLAB
% write-file-hooks:   (time-stamp)
% time-stamp-active:  t
% time-stamp-start:   "last edited: <"
% time-stamp-end:     ">"
% time-stamp-line-limit: 20
% End:
