function P = jvlap(M)
% P = jvlap(M) - Jonker and Volgenant algorithm for solving the
%                linear assignment problem
% INPUT:  M - [nxn] weight matrix
% OUTPUT: P - nearest permutation matrix
% 
% Copyright (C) 2010, Sergey Plis  [s.m.plis@gmail.com]
% last edited: <2010-10-19 23:16:11 pliz>
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free  Software Foundation; either  version 2 of the  License, or
% (at your option) any later version.
%
% This program is distributed in the  hope that it will be useful, but
% WITHOUT  ANY   WARRANTY;  without  even  the   implied  warranty  of
% MERCHANTABILITY or  FITNESS FOR A  PARTICULAR PURPOSE.  See  the GNU
% General Public License for more details.

M          = log(M/max(M(:)) + eps)./log(1.2); % stretching the values
[c,P]      = BOLapMex(size(M), M'); 
P          = P+1;

% Local Variables:
% mode: MATLAB
% write-file-hooks:   (time-stamp)
% time-stamp-active:  t
% time-stamp-start:   "last edited: <"
% time-stamp-end:     ">"
% time-stamp-line-limit: 20
% End:
