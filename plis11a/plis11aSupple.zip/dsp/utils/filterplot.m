function [obserr, poserr] = filterplot(vmf_obs, vmf_pos, x, Q, iQ, ...
                                       ei, eo, pobs, kind,iter)

sx = 2; sy = 3;
colormap([[1 0 0];[0 0 0];[1 1 1]]);
observed = size(pobs,2);

Ppos   = nearest_perm(vmf_pos.mu, iQ, kind);
Ptru   = nearest_perm(x,          iQ, kind);
n      = size(Ptru,1); Pobs = zeros(n,n);
Pobs(sub2ind([n,n], pobs(2,:), pobs(1,:))) = 1;
t = abs(Pobs-Ptru);
obserr = (sum(t(sub2ind([n,n], pobs(2,:), pobs(1,:)))) + n-size(pobs,2))/n;
poserr = sum(sum(abs(Ppos-Ptru)))/2/n;

if  exist('pobs'), 
    mask = zeros(n,n); 
    mask(sub2ind([n,n],pobs(2,:),pobs(1,:))) = 1;
else 
    mask = ones(n,n);
end

ss = 0.2; % subplot scale
mask = ones(n,n);
cPobs = Pobs;
cPobs(find((Pobs-Ptru)>0)) = -1;
cPobs = cPobs .* mask;

h=subplot(sx, sy, sy + 1); imagesc(cPobs,[-1,1]); axis square
set(gca,'XTick',[],'YTick',[]);
p = get(h,'position'); xl = p(3) + p(3)*ss; yl = p(4) + p(4)*ss;
set(h,'position',[p(1) p(2) xl yl]);
ylabel(sprintf('observed %1.0f objects', observed));
xlabel(sprintf('observation error: %0.3f', obserr));
cPpos = Ppos; cPpos(find((Ppos-Ptru)>0)) = -1;
h=subplot(sx, sy, sy + 2); imagesc(cPpos,[-1,1]); axis square
set(gca,'XTick',[],'YTick',[]);
xlabel(sprintf('inference error: %0.3f', poserr));
p = get(h,'position'); xl = p(3) + p(3)*ss; yl = p(4) + p(4)*ss;
set(h,'position',[p(1) p(2) xl yl]);
%if iter < 2,
    h=subplot(sx, sy, sy + 3); imagesc(Ptru, [-1,1]); axis square
    set(gca,'XTick',[],'YTick',[]);
    xlabel(sprintf('%d true identities',n));
    p = get(h,'position'); xl = p(3) + p(3)*ss; yl = p(4) + p(4)*ss;
    set(h,'position',[p(1) p(2) xl yl]);
  %end

subplot(sx, sy, [1,2,3]);
plot(ei(1:max(iter-1,1)), 'g'); hold on;
plot(eo(1:max(iter-1,1)),'b','LineWidth',0.5);  hold off;
grid on;
xlabel('iteration number');
ylabel('relative error');
axis([0,size(ei,2)-1,0,1]);
set(gca,'YAxisLocation','left');
set(gca,'XAxisLocation','top');
legend('inference','observation','Location','NorthEastOutside');

if iter < 2,
ph = axes('Position',[.15 .01 .8 .05],'Visible','on','xtick',[], ...
          'ytick',[]);
plot(0.01,0.5,'sk','MarkerEdgeColor','w','MarkerFaceColor','w')
set(gca,'color','k')
ylim([0,1])
xlim([0,1])
set(gca(),'ytick',[],'xtick',[]);
hold on
plot(0.51,0.5,'sr','MarkerFaceColor','r','MarkerEdgeColor','r')
text(0.03,0.35,'correct identities','Color','w');
text(0.53,0.35,'incorrect identities','Color','r');
hold off
end
drawnow();
