function allfig = mfigure(mtitle)
ssz = get(0,'ScreenSize');
fh = 0.5 * ssz(4);
fw = 3*fh/2; 
sx0 = 0.5 * ssz(3); sy0 = 0.5 * ssz(4);
allfig = figure('Position',[sx0-0.5*fw sy0-0.5*fh fw fh],'Menu', ...
                'none','Toolbar','none', 'Name', mtitle);
