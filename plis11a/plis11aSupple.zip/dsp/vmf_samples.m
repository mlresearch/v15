function samples = vmf_samples(mu,kappa,n)
%
% vmf_samples generates random draws from von Mises-Fisher distribution
%
% INPUT:
% mu       - the mean vector of the distribution (row vector)
% kappa    - the spread parameter (scalar)
% n        - number of samples to generate (integer)
%
% OUTPUT:
% samples  -  [n  x  d]   matrix  of  random  draws  from  von  Mises-Fisher
%             distribution with  parameters mu and  kappa centered at  0 and
%             with radius 1
%
% last edited: <2010-10-19 23:32:05 pliz>
%
% EXAMPLE:
%  mu = randn(1,3);
%  mu = mu/norm(mu,2);
%  ss = vmf_samples(mu',200,300);
%  plot3(ss(:,1),ss(:,2),ss(:,3),'mo', 'MarkerFaceColor',[0 0 0]);
%  hold on;
%  plot3([0 mu(1)]',[0 mu(2)]',[0 mu(3)]');
%  xlabel('x'); ylabel('y'); zlabel('z');   
%  axis equal;
%  xlim([-1,1]); ylim([-1,1]);zlim([-1,1]);
%  grid on;
%  hold off;
%
% REFERENCES:
% Dhillon, I.,  and Sra, S.: Modeling data  using directional distributions,
% University of Texas at Austin, 2003 (Figure 4)
%
%
% This program  is free software; you  can redistribute it  and/or modify it
% under the terms of the GNU General Public License as published by the Free
% Software Foundation; either version 2  of the License, or (at your option)
% any later version.
%
% This  program is  distributed in  the  hope that  it will  be useful,  but
% WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
% or FITNESS FOR  A PARTICULAR PURPOSE.  See the  GNU General Public License
% for more details.
%
% Copyright (C) 2009, Sergey Plis  [s.m.plis@gmail.com]
% Last edited: Wed Aug 19 00:19:37 MDT 2009

    d = length(mu);
    t1 = sqrt(4*kappa^2+(d-1)^2);
    b = (-2*kappa + t1)/(d-1);
    x0 = (1-b)/(1+b);
    samples = zeros(n,d);

    m = 0.5*(d-1);
    c = kappa*x0 + (d-1)*log(1-x0^2);

    for i=1:n,
        t = -1000;
        u = 1;
        while (t<log(u)),
            z = betarnd(m,m);
            u = rand;
            w = (1-(1+b)*z)/(1-(1-b)*z);
            t = kappa*w + (d-1)*log(1-x0*w);
        end
        
      %% a vector from uniform distribution on a sphere
        v = randn(1,d-1);
        v = v/norm(v,2);
        
        samples(i,1:d-1) = sqrt(1-w^2)*v;
        samples(i,d)=w;
    end
    
    if 0,
      %% Rotate the samples to cluster around \mu
      %% Givens-rotations approach: O(n*d)
        samples = fliplr(samples); % now samples are centered around x-axis
        [givrot, tmpv] = givenss(mu');
        if sign(tmpv(1))-1,
            samples = (-1)*samples;
        end
        igivrot = invgivens(givrot);
        samples = apinvgivenss(samples,igivrot);
    end
    if 1,
      %% QR-decomposition approach: O(d^3) + O(n*d^2)  
        mu      = mu/norm(mu,2); %make sure mu is normalized
        [Q,R]   = qr(mu);
        Q       = fliplr(Q);
        Q       = R(1)*Q;
        samples = samples * Q';
    end

  % Local Variables:
% mode: MATLAB
% write-file-hooks:   (time-stamp)
% time-stamp-active:  t
% time-stamp-start:   "last edited: <"
% time-stamp-end:     ">"
% time-stamp-line-limit: 20
% End:
