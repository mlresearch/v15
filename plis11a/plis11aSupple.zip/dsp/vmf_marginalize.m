function vmf = vmf_marginalize(vmf1, vmf2)
% vmf_marginalize(vmf1, vmf2) - computes the convolution of two
%                               von Mises-Fisher distributions
% INPUT:
% vmf1  and  vmf2  -  structures containing  means  and  concentration
%                     parameters  for distributions  of  interest. The
%                     structures must have 'mu' and 'kappa' fields
% OUTPUT:
% vmf              -  parameters of the result as a structure with
%                     fields 'mu' and 'kappa'

% Copyright (C) 2010, Sergey Plis  [s.m.plis@gmail.com]
% last edited: <2010-10-19 23:43:27 pliz>
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free  Software Foundation; either  version 2 of the  License, or
% (at your option) any later version.
%
% This program is distributed in the  hope that it will be useful, but
% WITHOUT  ANY   WARRANTY;  without  even  the   implied  warranty  of
% MERCHANTABILITY or  FITNESS FOR A  PARTICULAR PURPOSE.  See  the GNU
% General Public License for more details.

d         = length(vmf1.mu)/2;

vmf       = struct('mu',zeros(size(vmf1.mu)),'kappa',0.0);
bproduct  = bessel_ratio_Lentz(d,vmf1.kappa) * ...
    bessel_ratio_Lentz(d, vmf2.kappa);

vmf.mu    = vmf1.mu + vmf2.mu;
nrm1      = norm(vmf.mu,2);

vmf.mu    = vmf.mu / nrm1;
vmf.kappa = nrm1 / bessel_ratio_Lentz(d, bproduct);

% Local Variables:
% mode: MATLAB
% write-file-hooks:   (time-stamp)
% time-stamp-active:  t
% time-stamp-start:   "last edited: <"
% time-stamp-end:     ">"
% time-stamp-line-limit: 20
% End:
