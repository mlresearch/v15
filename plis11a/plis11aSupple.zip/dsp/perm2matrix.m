function M = perm2matrix(p) 
% M = perm2matrix(p) - converts a permutation p to its matrix
%                      operator representation
%
% INPUT:  p - n element permutation vector. It is  left to user to
%             check if it is a valid permutation.
% OUTPUT: M - [nxn] permutation matrix
%
% Copyright (C) 2010, Sergey Plis  [s.m.plis@gmail.com]
% last edited: <2010-10-20 01:17:43 pliz>
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free  Software Foundation; either  version 2 of the  License, or
% (at your option) any later version.
%
% This program is distributed in the  hope that it will be useful, but
% WITHOUT  ANY   WARRANTY;  without  even  the   implied  warranty  of
% MERCHANTABILITY or  FITNESS FOR A  PARTICULAR PURPOSE.  See  the GNU
% General Public License for more details.

n = length(p); 
M = zeros(n,n); 
M(p + [0:n-1]*n) = 1; 
M = M';

% Local Variables:
% mode: MATLAB
% write-file-hooks:   (time-stamp)
% time-stamp-active:  t
% time-stamp-start:   "last edited: <"
% time-stamp-end:     ">"
% time-stamp-line-limit: 20
% End:
