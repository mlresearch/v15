addpath('..');
addpath('../utils/');
addpath('../ifda/');
doplot    = 1;
kind      = 0;
obs_model = 0;
nf        = 1;
filenamein = 'flight06data.mat';
load(filenamein);
% dimension of the problem
  n         = size(data,2);
  runs      = 1000; % size(data,1); % uncomment to use the complete dataset
  perhid    = 0.0/100; % % of hidden objects
  plen      = n-round(perhid * n);
  pobs      = zeros(2,plen);
% basis matrices
  [Q Qort] = projector(n); iQ = [Q Qort];
% starting permutation
  x1        = perm2matrix(data(1,:));
  x0        = u2hs(x1(:), Q);
% concentrations
  kappa0    = 30;
  kappa_tr  = 1500;
  kappa_obs = n*nf;
%% observation model
  vmf_obs = struct('mu', x0, 'kappa', kappa_obs);
%% transition model
  vmf_trn = struct('mu', x0, 'kappa', kappa_tr);
%% posterior of the state
  vmf_pos = struct('mu', x0, 'kappa', kappa0);

  ei = zeros(1,runs); eo = zeros(1,runs);
  if doplot,
      allfig = mfigure(sprintf('air traffic control of %d flights',n));
  end

  for i = 1:runs,
    %% predict
      vmf_pos = vmf_marginalize(vmf_trn, vmf_pos);
    %% generate an observation -----------------------------------
      x1    = perm2matrix(data(i,:));
      x0    = u2hs(x1(:), Q);      
      switch obs_model
        case 0 % vMF noise
          y     = vmf_samples(x0, kappa_obs, 1)';  vmf_obs.mu = y;
        case 1 % proximity noise
          Mflip = proximityModel(coords(:,:,i), 0.8, 0.05);
          y     = perm2matrix(proximityCorrupt(data(i,:),Mflip));
          y     = u2hs(y(:), Q); vmf_obs.mu = y;
      end
      sigma = [1:n]*nearest_perm(y, iQ, kind);              
    %% partial observation    -----------------------------------
      pp        = randperm(n);
      pobs      = zeros(2,plen);
      pobs(1,:) = pp(1:plen);
      pobs(2,:) = sigma(pp(1:plen));
      vmf_obs   = vmf_pobs(pobs, kappa_obs, Q);
    %% update                  -----------------------------------
      vmf_pos    = vmf_multiply(vmf_obs, vmf_pos);
      vmf_trn.mu = vmf_pos.mu;

    %% keep track of errors    -----------------------------------
      if doplot,
          sfigure(allfig);
          [obserr, poserr] = filterplot(vmf_obs, vmf_pos, x0, ...
                                        [Q Qort], iQ, ei, eo, pobs, kind,i);
      else
          Pobs   = nearest_perm(vmf_obs.mu, iQ, kind);
          Ppos   = nearest_perm(vmf_pos.mu, iQ, kind);
          Ptru   = nearest_perm(x0,         iQ, kind);
          obserr = sum(sum(abs(Pobs-Ptru)))/2/n;
          poserr = sum(sum(abs(Ppos-Ptru)))/2/n;
      end
      eo(i) = obserr;
      ei(i) = poserr;
  end
