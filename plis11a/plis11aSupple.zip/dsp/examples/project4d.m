addpath('..');
n = 3;
cc= 1;
kappa = 3;
samples=300;
[Q Qort] = projector(n); iQ = [Q Qort];

idx = [1:(n-1)^2];
pp = perms([1:n]);
ppm = zeros(size(pp,1),n^2);
ppu = zeros(size(pp,1),(n-1)^2);
for i=1:size(pp,1), tmp = perm2matrix(pp(i,:)); ppm(i,:) = tmp(:); end
for i=1:size(pp,1), ppu(i,:) = u2hs(ppm(i,:)',Q); end
ss = vmf_samples(ppu(1,:)', kappa, samples);
probs = vmf(ppu(cc,idx(1:3))',kappa,ss(:,idx(1:3))');
probs = probs/max(probs(:));

ssz = get(0,'ScreenSize');
fh = 0.5 * ssz(4);
fw = 4*fh; 
sx0 = 0.5 * ssz(3); sy0 = 0.5 * ssz(4);
allfig = figure('Position',[sx0-0.5*fw sy0-0.5*fh fw fh],'Menu', ...
                'none','Toolbar','none', 'Name', ...
                '4D sphere axis-parallel projections to 3D');
for j=1:4, 
    subplot(1,4,j); 
    idx = [1:(n-1)^2];
    idx(j)=[];
    cc=1;
    disp(pp(cc,:));
    plot3(ppu(cc,idx(1)), ppu(cc,idx(2)),ppu(cc,idx(3)),'o', ...
	  'MarkerSize',20, ...
	  'MarkerEdgeColor', 'k',...
	  'MarkerFaceColor',[0 1 0]);
    hold on;
    box on;
    nn = [2,3,5]';
    plot3(ppu(nn,idx(1)), ppu(nn,idx(2)),ppu(nn,idx(3)),'o', ...
	  'MarkerSize',10, ...
	  'MarkerEdgeColor', 'k',...
	  'MarkerFaceColor',[0.9 1 0.5]);
    nn = [4,6]';
    plot3(ppu(nn,idx(1)), ppu(nn,idx(2)),ppu(nn,idx(3)),'o', ...
	  'MarkerSize',10, ...
	  'MarkerEdgeColor', 'k',...
	  'MarkerFaceColor',[0.35 1 0.85]);
    if 0,
	for k=1:factorial(n),
	    plot3(ppu(k,idx(1)),ppu(k,idx(2)),ppu(k,idx(3)),...
		  'o',...
		  'MarkerSize', 5*k+10,...
		  'MarkerEdgeColor','k');
	end
    end
    for k=1:samples,
	plot3(ss(k,idx(1)),ss(k,idx(2)),ss(k,idx(3)),...
	      'ro','MarkerSize',(probs(k)^0.7)*10+eps,...
	      'MarkerFaceColor',[1,1-probs(k),1-probs(k)],...
	      'MarkerEdgeColor','k');
    end
    set(gca,'xtick',[-1,0,1],'ytick',[-1,0,1],'ztick',[-1,0,1]);
    view(76,56);
    xlim([-1,1]);     ylim([-1,1]);    zlim([-1,1]);
    grid off;
    if ~in_octave(),
        alpha 0.5;
        axis vis3d;
    else
        axis equal;
    end
    hold off; 
end

rotate3d on;
