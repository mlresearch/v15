% an example script of using dsp (bikhoff) code in the case of a fixed
% hidden permutation: aggregation problem
%
% Copyright (c) 2010, Sergey Plis
% last edited: <2011-01-26 22:07:45 pliz>
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free  Software Foundation; either  version 2 of the  License, or
% (at your option) any later version.
%
% This program is distributed in the  hope that it will be useful, but
% WITHOUT  ANY   WARRANTY;  without  even  the   implied  warranty  of
% MERCHANTABILITY or  FITNESS FOR A  PARTICULAR PURPOSE.  See  the GNU
% General Public License for more details.
  addpath('..');        % the toolkit
  addpath('../utils/'); % utilities
%% parameters to modify ----------------------------------------------
  doplot = true;
  kind = 1; % what solver to use
% dimension of the problem
  n         = 10;
  perhid    = 0.0/100;
  runs      = 200;
  plen      = n-round(perhid * n); pobs = zeros(2,plen);
  kappa0    = log(sqrt(n));
  kappa_obs = n*2; % observation noise concentration
%% main code           -----------------------------------------------
% basis matrices
  [Q Qort] = projector(n); iQ = [Q Qort];
% the "true" permutation
  x1        = perm2matrix(randperm(n)); % eye(n);
  x0        = u2hs(x1(:), Q);
% random initialization
  x2        = perm2matrix(randperm(n));
  x2        = u2hs(x2(:), Q); 
% observation model
  vmf_obs = struct('mu', x0, 'kappa', kappa_obs);
% posterior of the state
  vmf_pos = struct('mu', x2, 'kappa', kappa0);
  ei = zeros(1,runs); eo = zeros(1,runs);
  if doplot,
      allfig = mfigure('fixed permutation: DSP');      
  end
% main loop
  for i = 1:runs,
    %% generate an observation -----------------------------------
      y     = vmf_samples(x0, kappa_obs, 1)';  vmf_obs.mu = y;
      sigma = [1:n]*nearest_perm(y, iQ, kind);
    %% partial observation    -----------------------------------
      pp        = randperm(n);
      pobs      = zeros(2,plen);
      pobs(1,:) = pp(1:plen);
      pobs(2,:) = sigma(pp(1:plen));
      vmf_obs   = vmf_pobs(pobs, kappa_obs, Q);
    %% update                  -----------------------------------
      vmf_pos = vmf_multiply(vmf_obs, vmf_pos);
      x       = nearest_perm(vmf_pos.mu, iQ, kind);
    %% keep track of errors    -----------------------------------
      if doplot,
          sfigure(allfig);
          [obserr, poserr] = filterplot(vmf_obs, vmf_pos, x0, ...
                                        [Q Qort], iQ, ei, eo, pobs, ...
                                        kind,i);
      else
          Pobs   = nearest_perm(vmf_obs.mu, iQ, kind);
          Ppos   = nearest_perm(vmf_pos.mu, iQ, kind);
          Ptru   = nearest_perm(x0,         iQ, kind);
          obserr = sum(abs(Pobs(:)-Ptru(:)))/2/n;
          poserr = sum(abs(Ppos(:)-Ptru(:)))/2/n;
      end
      ei(i) = poserr;
      eo(i) = obserr;
      if ei(i) == 0, break; end;
  end

% Local Variables:
% mode: MATLAB
% write-file-hooks:   (time-stamp)
% time-stamp-active:  t
% time-stamp-start:   "last edited: <"
% time-stamp-end:     ">"
% time-stamp-line-limit: 20
% End:
