load('icosphere.mat');
addpath('../utils');
% generate random mean
  mu = randn(3,1);
% generate random kappa
  kappa = rand()*10;
  
% generating data
  c = vmf(mu, kappa, vts);
  
% plotting the result
  if ~exist('allfig'),
      ssz = get(0,'ScreenSize');
      fh = 0.5 * ssz(4); fw = fh; 
      sx0 = 0.5 * ssz(3); sy0 = 0.5 * ssz(4);
      allfig = figure('Position',[sx0-0.5*fw sy0-0.5*fh fw fh],'Menu', ...
                      'none','Toolbar','none', 'Name', ...
                      'fixed permutation'); 
  else
      sfigure(allfig);
  end
  
  trisurf(tri',vts(1,:), vts(2,:), vts(3,:), c);
  title(sprintf('kappa = %f\n  mu = [%f,%f,%f]',kappa, mu(1), mu(2), mu(2)));
  
  shading interp
  colormap hot
  axis vis3d
  rotate3d on
