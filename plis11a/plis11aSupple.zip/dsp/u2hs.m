function r = u2hs(x, Q)
% r = u2hs(x,Q)  - project a vectorized permutation  matrix x onto the
%                  surface  of  a   unit  radius  hypersphere  in  the
%                  subspace spanned by orthogonal basis vectors of Q
% INPUT:  x - a n^2 element vector representing a permutation
% OUTPUT: Q - Birkhoff polytope subspace orthogonal basis
%
% Copyright (C) 2010, Sergey Plis  [s.m.plis@gmail.com]
% last edited: <2010-10-19 22:33:49 pliz>
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free  Software Foundation; either  version 2 of the  License, or
% (at your option) any later version.
%
% This program is distributed in the  hope that it will be useful, but
% WITHOUT  ANY   WARRANTY;  without  even  the   implied  warranty  of
% MERCHANTABILITY or  FITNESS FOR A  PARTICULAR PURPOSE.  See  the GNU
% General Public License for more details.

sn = sqrt(length(x));
r = Q' * (x - 1/sn)/sqrt(sn - 1);

% Local Variables:
% mode: MATLAB
% write-file-hooks:   (time-stamp)
% time-stamp-active:  t
% time-stamp-start:   "last edited: <"
% time-stamp-end:     ">"
% time-stamp-line-limit: 20
% End:
