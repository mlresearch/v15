function W = pbasis(N)
% W = pbasis(n) - generate orthogonal  vectors  that represent  the
%                 subspace orthogonal  to the subspace  containing the
%                 Birkhoff polytope
% INPUT:      n - size of the permutation specifying the Birkhoff polytope
% OUTPUT:     W - [n^2 x 2n-1] matrix of orthogonal columns
%
% Copyright (C) 2010, Sergey Plis  [s.m.plis@gmail.com]
% last edited: <2010-10-19 22:37:36 pliz>
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free  Software Foundation; either  version 2 of the  License, or
% (at your option) any later version.
%
% This program is distributed in the  hope that it will be useful, but
% WITHOUT  ANY   WARRANTY;  without  even  the   implied  warranty  of
% MERCHANTABILITY or  FITNESS FOR A  PARTICULAR PURPOSE.  See  the GNU
% General Public License for more details.

W = zeros(N^2,2*N);
for i = 1:N,
  W(N*[0:N-1]+i, i+N)       = 1;
  W((i-1)*N+1:(i-1)*N+N, i) = 1;
end
W = W(:, 1:end-1);

% Local Variables:
% mode: MATLAB
% write-file-hooks:   (time-stamp)
% time-stamp-active:  t
% time-stamp-start:   "last edited: <"
% time-stamp-end:     ">"
% time-stamp-line-limit: 20
% End:
