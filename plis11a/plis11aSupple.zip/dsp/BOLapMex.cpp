/***************************************************************************
 *   Copyright (C) 2007 by Boguslaw Obara                                  *
 *   http://boguslawobara.net                                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#include <math.h>
#include <string.h>
#include <stdio.h>
#include "BOLap.cpp"

extern "C" {
	#include "mex.h"
}
//---------------------------------------------------------------------------
// function: BOLapMex - entry point from Matlab via mexFucntion()
// INPUTS:
//   nlhs 		- number of left hand side arguments (outputs)
//   plhs[] 	- pointer to table where created matrix pointers are
//            		to be placed
//   nrhs 		- number of right hand side arguments (inputs)
//   prhs[] 	- pointer to table of input matrices
//---------------------------------------------------------------------------

void BOLapMex( int nlhs, mxArray *plhs[], int nrhs, const mxArray  *prhs[] )
{
	// Check for proper number of input and output arguments
	//-----------------------------------------------------------
	if (nrhs < 1) mexErrMsgTxt("Input arguments required. Usage: [cost, rows[]] = BOLapMex(dim, assigncost[][])");
	if (nlhs < 1) mexErrMsgTxt("One output argument required. Usage: [cost, rows[]] = BOLapMex(dim, assigncost[][])");
	if (nrhs > 2) mexErrMsgTxt("Too many input arguments.");
	if (nlhs > 2) mexErrMsgTxt("Too many output arguments.");

	//-----------------------------------------------------------
	double *assigncostValues;
	int assigncostrowLen, assigncostcolLen;
	int dim;
	int* rowsol;
	int* colsol;
	int* u;
	int* v;
	int** assigncost;
	int lapcost;
	double* rowsolD;
	double* lapcostD;

	if (nrhs > 0 && nlhs > 0) {
		// printf("Start :)\n");		
		// get inputs
		//-----------------------------------------------------------
		//Get the Integer dim
		dim = (int)mxGetScalar(prhs[0]);

		//Get matrix assigncost
		assigncostValues = mxGetPr(prhs[1]);
		assigncostrowLen = mxGetN(prhs[1]);
		assigncostcolLen = mxGetM(prhs[1]);
		//printf("Array: %d , %d ",assigncostrowLen, assigncostcolLen);
		assigncost = new int*[assigncostrowLen];
		for (int i = 0; i < assigncostrowLen; i++)
			assigncost[i] = new int[assigncostcolLen];
		for(int i=0;i<assigncostrowLen;i++)
			for(int j=0;j<assigncostcolLen;j++)
				assigncost[i][j] = (int)assigncostValues[(i*assigncostcolLen)+j];

		// create output
		//-----------------------------------------------------------
		plhs[0]  = mxCreateDoubleMatrix(1, 1, mxREAL);
		lapcostD = mxGetPr(plhs[0]);
		plhs[1]  = mxCreateDoubleMatrix(dim, 1, mxREAL);
		rowsolD  = mxGetPr(plhs[1]);

		// Run
		//-----------------------------------------------------------
		rowsol = new int[dim];
		colsol = new int[dim];
		u = new int[dim];
		v = new int[dim];
		memset(rowsol, 0, sizeof(int)*dim);
		memset(colsol, 0, sizeof(int)*dim);
		memset(u, 0, sizeof(int)*dim);
		memset(v, 0, sizeof(int)*dim);
		lapcost = BOLap(dim, assigncost, rowsol, colsol, u, v);
		
		for(int i=0; i<dim; i++)
			rowsolD[i] = (double)rowsol[i];

		lapcostD[0] = (double)lapcost;
		//printf("Finished :)\n");
	}
	delete rowsol;
	delete colsol;
	delete u;
	delete v;
	for (int i = 0; i < assigncostrowLen; i++)
	  delete assigncost[i];
	delete assigncost;
}

extern "C" {
  //--------------------------------------------------------------
  // mexFunction - Entry point from Matlab. From this C function,
  //   simply call the C++ application function, above.
  //--------------------------------------------------------------
  void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray  *prhs[] )
  {
    BOLapMex(nlhs, plhs, nrhs, prhs);
  }
}
