function f = bessel_ratio_Lentz(order, x)
% f  = besel_ratio_Lentz(order,x)  -  computes ratio  of two  modified
%                      Bessel  functions  of  the  first  kind  at  x,
%                      denominator's  order is  decremented by  1 with
%                      respect to numerator
% INPUT: oder - order of the numerator function
%           x - value at which to compute the ratio
% based on:
% Lentz,  W.   J.:  Generating  Bessel  functions  in  Mie  scattering
%  calculations using  continued fractions, Applied  Optics 15, volume
%  15, 668–671, 1976


% Copyright (C) 2010, Sergey Plis  [s.m.plis@gmail.com]
% last edited: <2010-10-20 00:22:34 pliz>
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free  Software Foundation; either  version 2 of the  License, or
% (at your option) any later version.
%
% This program is distributed in the  hope that it will be useful, but
% WITHOUT  ANY   WARRANTY;  without  even  the   implied  warranty  of
% MERCHANTABILITY or  FITNESS FOR A  PARTICULAR PURPOSE.  See  the GNU
% General Public License for more details.

tiny = 1e-30;

f = tiny;
C = f;
D = 0;
counter = 1;
while true
    b = 2*(order + counter)/x;
    D = b + D;
    if D == 0, D = tiny; end
    C = b + 1/C;
    if C == 0, C = tiny; end
    D = 1/D;
    delta = C*D;
    f = f*delta;
    if (abs(delta - 1) < eps), return; end
    counter = counter + 1;
end

% Local Variables:
% mode: MATLAB
% write-file-hooks:   (time-stamp)
% time-stamp-active:  t
% time-stamp-start:   "last edited: <"
% time-stamp-end:     ">"
% time-stamp-line-limit: 20
% End:
