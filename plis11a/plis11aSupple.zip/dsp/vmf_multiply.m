function vmf = vmf_multiply(vmf1, vmf2)
% vmf_multiply(vmf1, vmf2) - computes the product of two
%                            von Mises-Fisher distributions
% INPUT:
% vmf1  and  vmf2  -  structures containing  means  and  concentration
%                     parameters  for distributions  of  interest. The
%                     structures must have 'mu' and 'kappa' fields
% OUTPUT:
% vmf              -  parameters of the result as a structure with
%                     fields 'mu' and 'kappa'
%
% Copyright (C) 2010, Sergey Plis  [s.m.plis@gmail.com]
% last edited: <2011-03-22 11:43:46 pliz>
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free  Software Foundation; either  version 2 of the  License, or
% (at your option) any later version.
%
% This program is distributed in the  hope that it will be useful, but
% WITHOUT  ANY   WARRANTY;  without  even  the   implied  warranty  of
% MERCHANTABILITY or  FITNESS FOR A  PARTICULAR PURPOSE.  See  the GNU
% General Public License for more details.

vmf       = struct('mu',zeros(size(vmf1.mu)),'kappa',0.0);
x         = vmf1.mu * vmf1.kappa + vmf2.mu * vmf2.kappa;
vmf.kappa = norm(x,2); vmf.mu = x/vmf.kappa;

% Local Variables:
% mode: MATLAB
% write-file-hooks:   (time-stamp)
% time-stamp-active:  t
% time-stamp-start:   "last edited: <"
% time-stamp-end:     ">"
% time-stamp-line-limit: 20
% End:
