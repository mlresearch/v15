function r = vmf(mu, kappa, x)
d = length(mu);
% compute in the log space
  logvmf = ((d/2)-1) * log(kappa) - log((2*pi)^(d/2)*besseli(d/2-1,kappa)) ...
           + kappa * (mu'*x);
  r = exp(logvmf);