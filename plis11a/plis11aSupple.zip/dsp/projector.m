function [P1 P2] = projector(n)
% [Q Qort] =  projector(n) - generate 2 parts  of the orthogonal basis
%                            of the space that contains the Birkhoff
%                            polytope of n objects
% INPUT:  n - size of the permutation
% OUTPUT: Q - (n-1)^2 orthogonal basis vectors that represent the
%             subspace of the Birkhoff polytope
%      Qort - 2n-1 orthogonal basis vectors that represent the
%             remaining subspace orthogonal to that specified by Q
%
% Copyright (C) 2010, Sergey Plis  [s.m.plis@gmail.com]
% last edited: <2010-10-19 22:37:15 pliz>
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free  Software Foundation; either  version 2 of the  License, or
% (at your option) any later version.
%
% This program is distributed in the  hope that it will be useful, but
% WITHOUT  ANY   WARRANTY;  without  even  the   implied  warranty  of
% MERCHANTABILITY or  FITNESS FOR A  PARTICULAR PURPOSE.  See  the GNU
% General Public License for more details.

[Q R]  = qr(pbasis(n));
P1 = Q(:, 2*n:end);
P2 = Q(:, 1:(2*n-1));

% Local Variables:
% mode: MATLAB
% write-file-hooks:   (time-stamp)
% time-stamp-active:  t
% time-stamp-start:   "last edited: <"
% time-stamp-end:     ">"
% time-stamp-line-limit: 20
% End:
